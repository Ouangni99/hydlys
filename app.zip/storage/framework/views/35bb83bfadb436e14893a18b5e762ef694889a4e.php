<div class="inner-banner inner-bg2">
    <div class="container">
        <div class="inner-title">
            <ul>
                <li>
                    <a href="<?php echo e(route('accueil')); ?>">Accueil</a>
                </li>
                <li><i class='bx bx-chevron-right'></i></li>
                <li><?php echo e($fill); ?></li>
            </ul>
            <h3><?php echo e($fill); ?></h3>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\booking-app\resources\views/components/sub-menu.blade.php ENDPATH**/ ?>