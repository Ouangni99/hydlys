<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- Flaticon CSS -->
        <link rel="stylesheet" href="assets/fonts/flaticon.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <!-- Owl Carousel Min CSS -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <!-- Nice Select Min CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.min.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <!-- Jquery Ui CSS -->
        <link rel="stylesheet" href="assets/css/jquery-ui.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">
        <!-- Theme Dark CSS -->
        <link rel="stylesheet" href="assets/css/theme-dark.css">
        <link rel="stylesheet" href="assets/css/custom.css">

        <!-- Favicon -->
        <link rel="icon" type="image/png" href="assets/img/logos/logo-booking.png">

        <title>Hydlys - Résidence Hôtelière & Restaurant</title>
    </head>
    <body>

        <!-- PreLoader Start -->
        <div class="preloader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="sk-cube-area">
                        <div class="sk-cube1 sk-cube"></div>
                        <div class="sk-cube2 sk-cube"></div>
                        <div class="sk-cube4 sk-cube"></div>
                        <div class="sk-cube3 sk-cube"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- PreLoader End -->

        <!-- Start Navbar Area -->
        <div class="navbar-area">
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="index.html" class="logo">
                    <img src="assets/img/logos/logo-booking.png" width="150" class="logo-one" alt="Logo">
                    <img src="assets/img/logos/logo-booking.png" width="150" class="logo-two" alt="Logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light ">
                        <a class="navbar-brand" href="index.html">
                            <img src="assets/img/logos/logo-booking.png" class="logo-one" width="150" alt="Logo">
                            <img src="assets/img/logos/logo-booking.png" class="logo-two" width="150" alt="Logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto">
                                <li class="nav-item">
                                    <a href="#" class="nav-link active">
                                        Accueil
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="about.html" class="nav-link">
                                        Qui sommes nous
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Booking
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="#" class="nav-link">
                                        Nos chambres
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="contact.html" class="nav-link">
                                        Contact
                                    </a>
                                </li>

                                <li class="nav-item-btn">
                                    <a href="#" class="default-btn btn-bg-one border-radius-5">Réserver</a>
                                </li>
                            </ul>

                            <div class="nav-btn">
                                <a href="#" class="default-btn btn-bg-one border-radius-5">Réserver</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->

        <!-- Banner Area -->
        <div class="banner-area">
            <div class="container">
                <div class="banner-content">
                    <h1>Découvrez nos hôtel & résidence pour votre prochain séjour</h1>
                    <p>
                        Nous vous invitons à vous régaler dans un cadre trendy et élégant. Le restaurant offre un lieu de vie idéal pour un repas convivial, une savoureuse cuisine Africaine et Européenne.
                    </p>
                    <div class="banner-btn">
                        <a href="#" class="default-btn btn-bg-one border-radius-5">En savoir plus</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Banner Area End -->

        <!-- Banner Form Area -->
        <div class="banner-form-area">
            <div class="container">
                <div class="banner-form">
                    <form>
                        <div class="row align-items-center">
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <label>HEURE D'ARRIVÉE</label>
                                    <div class="input-group">
                                        <input id="datetimepicker" type="text" class="form-control" placeholder="11/02/2020">
                                        <span class="input-group-addon"></span>
                                    </div>
                                    <i class='bx bxs-chevron-down'></i>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <label>HEURE DE SORTIE</label>
                                    <div class="input-group">
                                        <input id="datetimepicker-check" type="text" class="form-control" placeholder="11/02/2020">
                                        <span class="input-group-addon"></span>
                                    </div>
                                    <i class='bx bxs-chevron-down'></i>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-2">
                                <div class="form-group">
                                    <label>INVITÉS</label>
                                    <select class="form-control">
                                        <option>01</option>
                                        <option>02</option>
                                        <option>03</option>
                                        <option>04</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <button type="submit" class="default-btn btn-bg-one border-radius-5">
                                    Réserver
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Banner Form Area End -->

        <!-- About Area -->
        <div class="about-area pt-100 pb-70">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="assets/img/about/about-img.jpg" alt="Images">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="about-content">
                            <div class="section-title">
                                <span>Qui sommes nous</span>
                                <h2>Vous avez de nombreuses raisons de nous choisir par rapport aux autres.</h2>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tristique augue quis neque ornare fermentum.
                                    In sit amet mattis diam. Sed id aliquam nulla. In porttitor et turpis non pretium.
                                </p>
                            </div>

                            <ul>
                                <li>
                                    <i class="flaticon-restaurant"></i>
                                    <div class="content">
                                        <h3>Restaurant</h3>
                                        <p>
                                            Nous sommes l'une des meilleures entreprises sur le marché mondial et nous disposons d'un restaurant.
                                            pour tous nos guides et tous nos clients.
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <i class="flaticon-wifi-signal-1"></i>
                                    <div class="content">
                                        <h3>Accès gratuit au Wifi</h3>
                                        <p>
                                            C'est l'endroit où vous obtiendrez une zone wifi gratuite à un prix raisonnable et cela vous aidera à passer des moments heureux et colorés.
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- About Area End -->

        <!-- Services Area -->
        <div class="services-area pb-70">
            <div class="container">
                <div class="section-title text-center">
                    <span>Nos services</span>
                    <h2>Nos services sur le marché mondial pour la réservation de nos clients</h2>
                </div>
                <div class="services-slider owl-carousel owl-theme pt-45">
                    <div class="services-item">
                        <i class="flaticon-hotel"></i>
                        <h3><a href="service-details.html">Réservation de chambres d'hôtel dans les lieux souhaités</a></h3>
                        <p>Vous pouvez facilement réserver une chambre d'hôtel dans un endroit qui vous convient. Cela vous permettra de vous sentir bien.</p>
                        <a href="service-details.html" class="get-btn">Obtenir le service</a>
                    </div>

                    <div class="services-item">
                        <i class="flaticon-resort"></i>
                        <h3><a href="service-details.html">Réservation d'un centre de villégiature dans un endroit approprié</a></h3>
                        <p>OVous pouvez facilement réserver une chambre dans un centre de villégiature à l'endroit qui vous convient le mieux. Cela vous permettra de vous sentir bien..</p>
                        <a href="service-details.html" class="get-btn">Obtenir le service</a>
                    </div>

                    <div class="services-item">
                        <i class="flaticon-buildings"></i>
                        <h3><a href="service-details.html">Réservation de salles de désherbage à l'endroit approprié</a></h3>
                        <p>La réservation d'une salle de désherbage est possible dans un endroit approprié, comme vous le souhaitez. Cela vous permettra de vous sentir bien.</p>
                        <a href="service-details.html" class="get-btn">Obtenir le service</a>
                    </div>

                    <div class="services-item">
                        <i class="flaticon-calendar"></i>
                        <h3><a href="service-details.html">Réservez dès maintenant pour garantir la disponibilité</a></h3>
                        <p>Vous pouvez facilement réserver une chambre d'hôtel dans un endroit qui vous convient. Cela vous permettra de vous sentir bien.</p>
                        <a href="service-details.html" class="get-btn">Obtenir le service</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Services Area End -->

        <!-- Reservation Area -->
        <div class="reservation-area section-bg pt-100 pb-70">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="reservation-content">
                            <div class="section-title">
                                <h2> <a href="reservation.html">Réservez facilement pour un sejour agréable</a></h2>
                                <p>
                                    C'est l'un des faits les plus importants et les plus cruciaux qui nous aide à faire une réservation facilement. Cette réservation vous aidera à faire votre voyage et votre période de voyage facilement.
                                    période de voyage. Cela vous aidera à rendre votre voyage plus facile et un voyage plus facile est plus utile pour vous. Alors, c'est parti !
                                </p>
                            </div>
                            <a href="#" class="default-btn btn-bg-one border-radius-5">Réservation rapide</a>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="reservation-img">
                            <img src="assets/img/reservation/reservation-img.jpg" alt="Images">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Reservation Area End -->

        <!-- Specialty Area End -->
        <div class="specialty-area pt-100 pb-70">
            <div class="container">
                <div class="section-title text-center">
                    <span>SPÉCIALITÉ</span>
                    <h2>Nos secteurs de spécialisation et tous les autres détails</h2>
                </div>

                <div class="row pt-45 align-items-center">
                    <div class="col-lg-6 col-xxl-7">
                        <div class="specialty-img">
                            <img src="assets/img/specialty/specialty-img1.jpg" alt="Images">
                        </div>
                    </div>

                    <div class="col-lg-6 col-xxl-5">
                        <div class="specialty-list">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="specialty-list-card">
                                        <i class="flaticon-decoration"></i>
                                        <h3>Décoration de l'espace</h3>
                                        <p>Nous sommes très attentifs à notre chambre et à toutes les décorations de la station. Alors, essayez-nous.</p>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="specialty-list-card">
                                        <i class="flaticon-champagne-glass"></i>
                                        <h3>Bar de luxe</h3>
                                        <p>Vous pouvez facilement bénéficier d'un accès gratuit à un bar de haut niveau à un prix raisonnable..</p>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="specialty-list-card">
                                        <i class="flaticon-fireworks"></i>
                                        <h3>hotel & Résidence 5 étoiles</h3>
                                        <p>Hydlys est une agence bien connue et l'agence est l'une des meilleures selon 5 Star Retting. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Specialty Area End -->

        <!-- Room Area -->
        <div class="room-area pt-100 pb-70 section-bg">
            <div class="container">
                <div class="section-title text-center">
                    <span>CHAMBRES</span>
                    <h2>Nos chambres et tarifs</h2>
                </div>
                <div class="row pt-45">
                    <div class="col-lg-4 col-md-6">
                        <div class="room-card">
                            <a href="room-details.html">
                                <img src="assets/img/room/room-img1.jpg" alt="Images">
                            </a>
                            <div class="content">
                                <h3><a href="room-details.html">Chambre de luxe</a></h3>
                                <ul>
                                    <li>320</li>
                                    <li>Par nuitée</li>
                                </ul>
                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star-half'></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="room-card">
                            <a href="room-details.html">
                                <img src="assets/img/room/room-img2.jpg" alt="Images">
                            </a>
                            <div class="content">
                                <h3><a href="room-details.html">Chambre individuelle</a></h3>
                                <ul>
                                    <li>300</li>
                                    <li>Par nuitée</li>
                                </ul>
                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star-half'></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="room-card">
                            <a href="room-details.html">
                                <img src="assets/img/room/room-img3.jpg" alt="Images">
                            </a>
                            <div class="content">
                                <h3><a href="room-details.html">Chambre double</a></h3>
                                <ul>
                                    <li>350</li>
                                    <li>Par nuitée</li>
                                </ul>
                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star-half'></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="room-card">
                            <a href="room-details.html">
                                <img src="assets/img/room/room-img4.jpg" alt="Images">
                            </a>
                            <div class="content">
                                <h3><a href="room-details.html">Salle de séjour</a></h3>
                                <ul>
                                    <li>370</li>
                                    <li>Par nuitée</li>
                                </ul>
                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star-half'></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="room-card">
                            <a href="room-details.html">
                                <img src="assets/img/room/room-img5.jpg" alt="Images">
                            </a>
                            <div class="content">
                                <h3><a href="room-details.html">Chambre de luxe</a></h3>
                                <ul>
                                    <li>270</li>
                                    <li>Par nuitée</li>
                                </ul>
                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star-half'></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="room-card">
                            <a href="room-details.html">
                                <img src="assets/img/room/room-img6.jpg" alt="Images">
                            </a>
                            <div class="content">
                                <h3><a href="room-details.html">Chambre présidentielle</a></h3>
                                <ul>
                                    <li>270</li>
                                    <li>Par nuitée</li>
                                </ul>
                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star-half'></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Room Area End -->

        <!-- FAQ Area -->
        <div class="faq-area pt-100 pb-70 section-bg">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-xxl-7">
                        <div class="faq-img">
                            <img src="assets/img/faq/faq-img1.jpg" alt="Images">
                        </div>
                    </div>

                    <div class="col-lg-6 col-xxl-5">
                        <div class="faq-content">
                            <div class="section-title">
                                <h2>Question frequement posées</h2>
                            </div>

                            <div class="faq-accordion">
                                <ul class="accordion">
                                    <li class="accordion-item">
                                        <a class="accordion-title" href="javascript:void(0)">
                                            <i class='bx bx-plus'></i>
                                            Comment réserver une chambre ou un lieu de villégiature ?
                                        </a>

                                        <div class="accordion-content">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at diam leo. Mauris a ante placerat,
                                                dignissim orci eget, viverra ante. Mauris ornare pellentesque augue. Curabitur leo nibh, ultrices
                                                vel ultricies eu, vulputate at felis.
                                            </p>
                                        </div>
                                    </li>

                                    <li class="accordion-item">
                                        <a class="accordion-title" href="javascript:void(0)">
                                            <i class='bx bx-plus'></i>
                                            Comment pourrai-je ajouter des éléments sur le portail d'administration ?
                                        </a>

                                        <div class="accordion-content">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at diam leo. Mauris a ante placerat,
                                                dignissim orci eget, viverra ante. Mauris ornare pellentesque augue. Curabitur leo nibh, ultrices
                                                vel ultricies eu, vulputate at felis.
                                            </p>
                                        </div>
                                    </li>

                                    <li class="accordion-item">
                                        <a class="accordion-title" href="javascript:void(0)">
                                            <i class='bx bx-plus'></i>
                                            Quels sont les avantages de ces agences ?
                                        </a>

                                        <div class="accordion-content">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at diam leo. Mauris a ante placerat,
                                                dignissim orci eget, viverra ante. Mauris ornare pellentesque augue. Curabitur leo nibh, ultrices
                                                vel ultricies eu, vulputate at felis.
                                            </p>
                                        </div>
                                    </li>

                                    <li class="accordion-item">
                                        <a class="accordion-title active" href="javascript:void(0)">
                                            <i class='bx bx-plus'></i>
                                            Comment effectuer le paiement de la réservation de la chambre ?
                                        </a>

                                        <div class="accordion-content show">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at diam leo. Mauris a ante placerat,
                                                dignissim orci eget, viverra ante. Mauris ornare pellentesque augue. Curabitur leo nibh, ultrices
                                                vel ultricies eu, vulputate at felis.
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- FAQ Area End -->

        <!-- Footer Area -->
        <footer class="footer-area footer-bg">
            <div class="container">
                <div class="footer-top pt-100 pb-70">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-6">
                            <div class="footer-widget">
                                <div class="footer-logo">
                                    <a href="index.html">
                                        <img src="assets/img/logos/logo-booking.png" alt="Images" width="150">
                                    </a>
                                </div>
                                <p>
                                    Aenean finibus convallis nisl sit amet hendrerit. Etiam blandit velit non lorem mattis, non ultrices eros bibendum .
                                </p>
                                <ul class="footer-list-contact">
                                    <li>
                                        <i class='bx bx-home-alt'></i>
                                        <a href="#">123 Stanton, Virginia, USA</a>
                                    </li>
                                    <li>
                                        <i class='bx bx-phone-call'></i>
                                        <a href="tel:+1-(123)-456-7890">+1 (123) 456 7890</a>
                                    </li>
                                    <li>
                                        <i class='bx bx-envelope'></i>
                                        <a href="mailto:hello@atoli.com">hello@atoli.com</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="footer-widget pl-5">
                                <h3>Links</h3>
                                <ul class="footer-list">
                                    <li>
                                        <a href="about.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            About Us
                                        </a>
                                    </li>
                                    <li>
                                        <a href="services-1.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Services
                                        </a>
                                    </li>
                                    <li>
                                        <a href="team.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Team
                                        </a>
                                    </li>
                                    <li>
                                        <a href="gallery.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Gallery
                                        </a>
                                    </li>
                                    <li>
                                        <a href="terms-condition.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Terms
                                        </a>
                                    </li>
                                    <li>
                                        <a href="privacy-policy.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Privacy Policy
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="footer-widget">
                                <h3>Useful Links</h3>
                                <ul class="footer-list">
                                    <li>
                                        <a href="index.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Home
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blog-1.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Blog
                                        </a>
                                    </li>
                                    <li>
                                        <a href="faq.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            FAQ
                                        </a>
                                    </li>
                                    <li>
                                        <a href="testimonials.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Testimonials
                                        </a>
                                    </li>
                                    <li>
                                        <a href="gallery.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Gallery
                                        </a>
                                    </li>
                                    <li>
                                        <a href="contact.html" target="_blank">
                                            <i class='bx bx-caret-right'></i>
                                            Contact Us
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="footer-widget">
                                <h3>Newsletter</h3>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                    Nullam tempor eget ante fringilla rutrum aenean sed venenatis .
                                </p>
                                <div class="footer-form">
                                    <form class="newsletter-form" data-toggle="validator" method="POST">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <input type="email" class="form-control" placeholder="Your Email*" name="EMAIL" required autocomplete="off">
                                                </div>
                                            </div>

                                            <div class="col-lg-12 col-md-12">
                                                <button type="submit" class="default-btn btn-bg-one">
                                                    Subscribe Now
                                                </button>
                                                <div id="validator-newsletter" class="form-result"></div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="copy-right-area">
                    <div class="row">
                        <div class="col-lg-8 col-md-8">
                            <div class="copy-right-text text-align1">
                                <p>
                                    Copyright @<script>document.write(new Date().getFullYear())</script> Hydlys. All Rights Reserved by
                                    <a href="https://hibootstrap.com/" target="_blank">HiBootstrap</a>
                                </p>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4">
                            <div class="social-icon text-align2">
                                <ul class="social-link">
                                    <li>
                                        <a href="#" target="_blank"><i class='bx bxl-facebook'></i></a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank"><i class='bx bxl-twitter'></i></a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank"><i class='bx bxl-instagram'></i></a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank"><i class='bx bxl-pinterest-alt'></i></a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank"><i class='bx bxl-youtube'></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End -->


        <!-- Jquery Min JS -->
        <script src="assets/js/jquery.min.js"></script>
        <!-- Bootstrap Bundle Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Magnific Popup Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl Carousel Min JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Nice Select Min JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Jquery Ui JS -->
        <script src="assets/js/jquery-ui.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js/meanmenu.js"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Custom JS -->
        <script src="assets/js/custom.js"></script>

    </body>
</html>
<?php /**PATH C:\laragon\www\booking-app\resources\views/welcome.blade.php ENDPATH**/ ?>