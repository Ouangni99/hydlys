<div class="navbar-area">
    <!-- Menu For Mobile Device -->
    <div class="mobile-nav">
        <a href="index.html" class="logo">
            <img src="assets/img/logos/logo-booking.png" width="150" class="logo-one" alt="Logo">
            <img src="assets/img/logos/logo-booking.png" width="150" class="logo-two" alt="Logo">
        </a>
    </div>

    <!-- Menu For Desktop Device -->
    <div class="main-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light ">
                <a class="navbar-brand" href="index.html">
                    <img src="assets/img/logos/logo-booking.png" class="logo-one" width="150" alt="Logo">
                    <img src="assets/img/logos/logo-booking.png" class="logo-two" width="150" alt="Logo">
                </a>

                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav m-auto">
                        <li class="nav-item">
                            <a href="<?php echo e(route('accueil')); ?>" class="nav-link <?php echo e(request()->routeIs('accueil') ? 'active':''); ?>">
                                Accueil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('about')); ?>" class="nav-link <?php echo e(request()->routeIs('about') ? 'active':''); ?>">
                                Qui sommes nous
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('booking')); ?>" class="nav-link <?php echo e(request()->routeIs('booking') ? 'active':''); ?>">
                                Réservation
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('room')); ?>" class="nav-link <?php echo e(request()->routeIs('room') ? 'active':''); ?>">
                                Nos chambres
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('contact')); ?>" class="nav-link <?php echo e(request()->routeIs('contact') ? 'active':''); ?>">
                                Contact
                            </a>
                        </li>
                    </ul>

                    <div class="nav-btn">
                        <a href="<?php echo e(route('signup')); ?>" class="default-btn btn-bg-one border-radius-5">S'inscrire</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\booking-app\resources\views/components/header.blade.php ENDPATH**/ ?>