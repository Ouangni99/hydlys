<div class="inner-banner inner-bg2">
    <div class="container">
        <div class="inner-title">
            <ul>
                <li>
                    <a href="{{ route('accueil') }}">Accueil</a>
                </li>
                <li><i class='bx bx-chevron-right'></i></li>
                <li>{{ $fill }}</li>
            </ul>
            <h3>{{ $fill }}</h3>
        </div>
    </div>
</div>
