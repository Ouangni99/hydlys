<?php

namespace App\enums;

enum RoomType: string
{

    case Rooms = 'chambre';
    case Suits = 'suite';
    case Villa = 'villa';
}
